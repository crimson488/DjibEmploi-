/*
  # Schéma initial pour DjibEmploi

  1. Nouvelles Tables
    - `job_applications`
      - `id` (uuid, clé primaire)
      - `candidate_name` (text, nom du candidat)
      - `email` (text, email du candidat)
      - `phone` (text, téléphone)
      - `resume_url` (text, lien vers le CV)
      - `cover_letter` (text, lettre de motivation)
      - `status` (text, statut de la candidature)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `user_id` (uuid, lien vers l'utilisateur)

  2. Sécurité
    - Activation RLS sur la table `job_applications`
    - Politiques pour lecture/écriture selon le rôle utilisateur
*/

CREATE TABLE job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_name text NOT NULL,
  email text NOT NULL,
  phone text,
  resume_url text,
  cover_letter text,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Politique pour les candidats (peuvent voir leurs propres candidatures)
CREATE POLICY "Users can view own applications"
  ON job_applications
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Politique pour soumettre une candidature
CREATE POLICY "Users can submit applications"
  ON job_applications
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Politique pour les recruteurs (peuvent tout voir)
CREATE POLICY "Recruiters can view all applications"
  ON job_applications
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'recruiter'
    )
  );