import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Briefcase } from 'lucide-react';
import Layout from './components/Layout';
import Home from './pages/Home';
import ApplicationForm from './pages/ApplicationForm';
import Applications from './pages/Applications';
import Dashboard from './pages/Dashboard';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'postuler', element: <ApplicationForm /> },
      { path: 'applications', element: <Applications /> },
      { path: 'tableau-de-bord', element: <Dashboard /> },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;